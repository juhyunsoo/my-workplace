/**
 * nav 태그를 출력해 주는 자바스크립트파일
 */
 var nav, div1, div2;

 //=====================================================================================
 function button() {//반응형 웹페이지 구현
     var button = document.createElement("button");
     button.setAttribute('type', 'button');
     button.setAttribute('class', 'navbar-toggler');
     button.setAttribute('type', 'button');
     button.setAttribute('data-toggle', 'collapse');
     button.setAttribute('data-target', '#navbarNav');
     button.setAttribute('aria-controls', 'navbarNav');
     button.setAttribute('aria-expanded', 'false');
     button.setAttribute('aria-label', 'Toggle navigation');
     button.innerHTML += "<span class='navbar-toggler-icon'></span>"
     nav.appendChild(button);
 }
 
 function pageList(accountNum, pageNum) {//페이지 목록 구현
 	 var div = document.createElement('div');
 	 div.setAttribute('class', 'collapse navbar-collapse');
 	 div.setAttribute('id', 'navbarNav');
     var ul = document.createElement('ul');
     ul.setAttribute('class', 'nav nav-tabs mr-auto');
     var alarm = document.createElement('li');
     var bbsA = document.createElement('li');
     var bbsB = document.createElement('li');
     var bbsC = document.createElement('li');
     alarm.setAttribute('class', 'nav-item');
     bbsA.setAttribute('class', 'nav-item');
     bbsB.setAttribute('class', 'nav-item');
     bbsC.setAttribute('class', 'nav-item');
 
 	 alarm.innerHTML += "<a class='nav-link' href='alarm.jsp'>알림</a>";
     bbsA.innerHTML += "<a class='nav-link' href='bbsA.jsp'>풀이게시판</a>";
     bbsB.innerHTML += "<a class='nav-link' href='bbsB.jsp'>질문게시판</a>";
     bbsC.innerHTML += "<a class='nav-link' href='bbsC.jsp'>관리자페이지</a>";
     
     if (pageNum == 0) {
         //active 없음
     }
     else if (pageNum == 1) {//alarm
         alarm.innerHTML = "<a class='nav-link active' href='alarm.jsp'>알림</a>";
     }
     else if (pageNum == 2) {//bbsA
         bbsA.innerHTML = "<a class='nav-link active' href='bbsA.jsp'>풀이게시판</a>";
     }
     else if (pageNum == 3) {//bbsB
         bbsB.setAttribute('class', 'nav-item active');
         bbsB.innerHTML = "<a class='nav-link active' href='bbsB.jsp'>질문게시판</a>";
     }
     else if (pageNum == 4) {//bbsC
         bbsC.setAttribute('class', 'nav-item active');
         bbsC.innerHTML = "<a class='nav-link active' href='bbsC.jsp'>관리자페이지</a>";
     }
 
 
     ul.appendChild(alarm);
     ul.appendChild(bbsA);
     ul.appendChild(bbsB);
     ul.appendChild(bbsC);
     div.appendChild(ul);
   
     
     var ul2 = document.createElement('ul');
     ul2.setAttribute('class', 'navbar-nav');
     var li = document.createElement('li');
     var temp = document.createElement('button');
     
     if (accountNum == 1) {//로그아웃 상태
         temp.setAttribute('class', 'btn btn-primary');
         temp.setAttribute('type', 'button');
         temp.setAttribute('onclick', "location.href='login.jsp'");
         temp.innerHTML += "로그인";
         li.appendChild(temp);
         ul2.appendChild(li);
     }
     else if (accountNum == 0) {//로그인 상태
         temp.setAttribute('class', 'btn btn-danger');
         temp.setAttribute('type', 'button');
         temp.setAttribute('onclick', "location.href='logoutAction.jsp'");
         temp.innerHTML += "로그아웃";
         var btn2 = document.createElement('button');
         btn2.setAttribute('class', 'btn btn-info');
         btn2.setAttribute('type', 'button');
         btn2.setAttribute('onclick', "location.href='edit.jsp'");
         btn2.innerHTML += "회원정보";
         li.appendChild(btn2);
         li.appendChild(temp);
         ul2.appendChild(li);
     }
     else {
         //버튼이 보이지 않음
     }
     div.appendChild(ul2);
     
     nav.appendChild(div);
 }
 //==================================================================================
 
 function createNav(accountNum, pageNum) {
     nav = document.getElementById("nav");
     nav.setAttribute('class', 'navbar navbar-expand-lg navbar-light fixed-top');
 	
 	 nav.innerHTML += "<a class='navbar-brand' href='main.jsp'>백준풀이공유 & Q&A</a>";
     button();//function
      
     pageList(accountNum, pageNum);//function
 }